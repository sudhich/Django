from django.db import models

# Create your models here.
class Student(models.Model):
    st_id=models.IntegerField()
    st_name=models.CharField(max_length=70)
    st_email=models.EmailField(max_length=70)
    st_pass=models.CharField(max_length=70)