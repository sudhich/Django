from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def course_fun(request):
    return HttpResponse('Hello Course')
def home_fun(request):
    return render(request,'course/home.html')
def dyna_fun(request):
    cname='Django'
    seat=10
    duration='4 Month'
    django_detail={'cn':cname,'st':seat,'dt':duration}
    return render(request, 'course/dyna.html', django_detail)
def middle_fun(request):
    print("I am view")
    return HttpResponse("This is home page")