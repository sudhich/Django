def my_middleware(get_response):
    print("One Time Initialization1")
    def my_fun(request):
        print("This is before view1")
        response=get_response(request)
        print("This is after view1")
        return response
    return my_fun
class Middlew_class:
    def __init__(self,get_response):
        self.get_response=get_response
        print("One time initialization2")
    def __call__(self,request):
        print("This is before view2")
        response=self.get_response(request)
        print('This is after view2')
        return response