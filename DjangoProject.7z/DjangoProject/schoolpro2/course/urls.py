from django.urls import path
from . import views


urlpatterns = [
    path("course_url/", views.course_fun),
]
