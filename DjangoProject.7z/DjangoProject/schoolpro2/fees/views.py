from django.shortcuts import render

# Create your views here.
def fees_fun(request):
    return render(request, 'fees/info.html', {'nm':'FEES'})