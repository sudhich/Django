from django.urls import path
from . import views


urlpatterns = [
    path("fees_url/", views.fees_fun),
]
